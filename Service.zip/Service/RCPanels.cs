﻿using System;
using System.Collections.Generic;
using System.Configuration.Install;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;

namespace RCPanels
{
    [RunInstaller(true)]
    public partial class RCPanels : Installer
    {
        public RCPanels()
        {
            var processInstaller = new ServiceProcessInstaller();
            var serviceInstaller = new ServiceInstaller();

            //set the privileges
            processInstaller.Account = ServiceAccount.LocalSystem;

            serviceInstaller.DisplayName = "RCPanels";
            serviceInstaller.StartType = ServiceStartMode.Automatic;

            //must be the same as what was set in Program's constructor
            serviceInstaller.ServiceName = "RCPanels";
            this.Installers.Add(processInstaller);
            this.Installers.Add(serviceInstaller);

            InitializeComponent();
        }
    }
}