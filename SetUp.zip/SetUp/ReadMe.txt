Version 1.0.0.3
COMBO1 1.0.0.1
COMBO2 1.0.0.3
Check your internet connection!!!
Close all applications (CLOSE ALSO Flight Simulator).
Extract SetUp.zip in a folder as you prefer.
Right click on setup.bat, execute as Administrator.
Follow on-screen instructions.