Version 1.0.0.6
COMBO1 1.0.0.2
COMBO2 1.0.0.4
MCDU 1.0.0.2
MCDU_NANO 1.0.0.2
Check your internet connection!!!
Close all applications (CLOSE ALSO Flight Simulator).
Extract SetUp.zip in a folder as you prefer.
Right click on setup.bat, execute as Administrator.
Follow on-screen instructions.