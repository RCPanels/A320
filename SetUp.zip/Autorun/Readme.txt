Locate file exe.xml in
C:\Users\*yourUser*\AppData\Local\Packages\Microsoft.FlightSimulator_8wekyb3d8bbwe\LocalCache

Open it with notepad and add text you can find in Autorun.txt.

The result will be similar to EXE.xml you find in this folder