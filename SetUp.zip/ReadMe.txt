Version 1.0.0.0
Extract SetUp.zip in a folder as you prefer.
Right click on setup.bat, execute as Administrator.
Follow on-screen instructions.